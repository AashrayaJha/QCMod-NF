Zs_patch_2:=[ MatrixAlgebra(CyclotomicField(3), 6) |
 ! [ CyclotomicField(3) | [ RationalField() | 0, 0 ], [ RationalField() | 0, 0 
], [ RationalField() | 0, 0 ], [ RationalField() | 11713050329/466387, 
2094250601/466387 ], [ RationalField() | -210853480/466387, -43029872/466387 ], 
[ RationalField() | 2103384/466387, 478920/466387 ], [ RationalField() | 0, 0 ],
[ RationalField() | 0, 0 ], [ RationalField() | 0, 0 ], [ RationalField() | 
744235527868739/274235556, 24696052125622/68558889 ], [ RationalField() | 
-22822453516/466387, -3626418252/466387 ], [ RationalField() | 228027070/466387,
41795000/466387 ], [ RationalField() | 0, 0 ], [ RationalField() | 0, 0 ], [ 
RationalField() | 0, 0 ], [ RationalField() | 10325157165537059/78353016, 
881644537778323/78353016 ], [ RationalField() | -1110090914436/466387, 
-124996337153/466387 ], [ RationalField() | 11109403187/466387, 
1532167651/466387 ], [ RationalField() | -11713050329/466387, -2094250601/466387
], [ RationalField() | -744235527868739/274235556, -24696052125622/68558889 ], [
RationalField() | -10325157165537059/78353016, -881644537778323/78353016 ], [ 
RationalField() | 0, 0 ], [ RationalField() | 0, 0 ], [ RationalField() | 0, 0 
], [ RationalField() | 210853480/466387, 43029872/466387 ], [ RationalField() | 
22822453516/466387, 3626418252/466387 ], [ RationalField() | 
1110090914436/466387, 124996337153/466387 ], [ RationalField() | 0, 0 ], [ 
RationalField() | 0, 0 ], [ RationalField() | 0, 0 ], [ RationalField() | 
-2103384/466387, -478920/466387 ], [ RationalField() | -228027070/466387, 
-41795000/466387 ], [ RationalField() | -11109403187/466387, -1532167651/466387 
], [ RationalField() | 0, 0 ], [ RationalField() | 0, 0 ], [ RationalField() | 
0, 0 ] ],

 ! [ CyclotomicField(3) | [ RationalField() | 0, 0 ], [ RationalField() | 0, 0 
], [ RationalField() | 0, 0 ], [ RationalField() | -17925746210/466387, 
310477395/466387 ], [ RationalField() | 327703928/466387, 2978908/466387 ], [ 
RationalField() | -3321768/466387, -111744/466387 ], [ RationalField() | 0, 0 ],
[ RationalField() | 0, 0 ], [ RationalField() | 0, 0 ], [ RationalField() | 
-161136063147133/39176508, 10771963978057/39176508 ], [ RationalField() | 
35118869985/466387, -1366756375/466387 ], [ RationalField() | -356456096/466387,
4634318/466387 ], [ RationalField() | 0, 0 ], [ RationalField() | 0, 0 ], [ 
RationalField() | 0, 0 ], [ RationalField() | -13561411902207200/68558889, 
12864991667215777/548471112 ], [ RationalField() | 1691514150975/466387, 
-300790278937/932774 ], [ RationalField() | -17193123775/466387, 
1056278980/466387 ], [ RationalField() | 17925746210/466387, -310477395/466387 
], [ RationalField() | 161136063147133/39176508, -10771963978057/39176508 ], [ 
RationalField() | 13561411902207200/68558889, -12864991667215777/548471112 ], [ 
RationalField() | 0, 0 ], [ RationalField() | 0, 0 ], [ RationalField() | 0, 0 
], [ RationalField() | -327703928/466387, -2978908/466387 ], [ RationalField() |
-35118869985/466387, 1366756375/466387 ], [ RationalField() | 
-1691514150975/466387, 300790278937/932774 ], [ RationalField() | 0, 0 ], [ 
RationalField() | 0, 0 ], [ RationalField() | 0, 0 ], [ RationalField() | 
3321768/466387, 111744/466387 ], [ RationalField() | 356456096/466387, 
-4634318/466387 ], [ RationalField() | 17193123775/466387, -1056278980/466387 ],
[ RationalField() | 0, 0 ], [ RationalField() | 0, 0 ], [ RationalField() | 0, 0
] ]
];
