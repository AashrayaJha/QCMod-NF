AttachSpec("QCMod.spec");
AttachSpec("coleman.spec");
import "applications.m": Qp_points;
import "singleintegrals.m": is_bad, xy_coordinates;
import "misc.m": function_field;

function transform(Q, A)
  
  // Apply the projective transformation given by the 2x2 matrix A to the 
  // curve defined by Q(x,y)=0. A acts on X and Z, but not Y.
  y := Parent(Q).1;
  x := BaseRing(Parent(Q)).1;
  K := BaseRing(BaseRing(Q));
  PK3<X,Y,Z>:=PolynomialRing(K,3);
  Q_dehom:=PK3!0;
  d := Degree(Q);
  for i:=0 to d do
    for j:=0 to Degree(Coefficient(Q,i)) do
      Q_dehom +:= Coefficient(Coefficient(Q,i),j)*Y^i*X^j;
    end for;
  end for;
  //We should probably have A^(-1), since det(A) is not always 1
  transformed_vars := [A[2,2]*X-A[1,2]*Z,Y,-A[2,1]*X+A[1,1]*Z];
  Q_hom := Homogenization(Q_dehom, Z);
  Q_trans_hom:=Evaluate(Q_hom, transformed_vars);
  Q_trans_dehom := Evaluate(Q_trans_hom, [X,Y,1]);
  Q_trans := Parent(Q)!0;
  for i:=0 to Degree(Q_trans_dehom, Y) do
    for j:=0 to Degree(Q_trans_dehom, Y)  do
      Q_trans +:= K!Coefficient(Coefficient(Q_trans_dehom, Y,i), X, j)*x^j*y^i;
    end for;
  end for;

  return Q_trans;
end function;

function good_transform(Q, A, embeddings : N := 6)
  // check if the transformation given by the 2x2 matrix A yields an
  // affine patch without bad residue disks. A acts on X and Z, but not Y.
  v_1,v_2 := Explode(embeddings);
  Q_trans := transform(Q, A);
  try 
    new_data1 := ColemanData(Q_trans, v_1, N);
  catch e;
    e;
    return false, _, _, _, _, _;
  end try;
  new_Qppoints_1 := Qp_points(new_data1 : Nfactor := 1.5);
//pts1 := [xy_coordinates(P, new_data1):P in new_Qppoints_1 | not is_bad(P, new_data1)];
  good1 := &and[not(is_bad(P, new_data1)) : P in new_Qppoints_1];
  if good1 then 
    try 
      new_data2 := ColemanData(Q_trans, v_2, N : useU:=false);
    catch e;
      e;
      return false, _, _, _, _, _;
    end try;
    new_Qppoints_2 := Qp_points(new_data2 : Nfactor := 1.5);
    good2 := &and[not(is_bad(P, new_data2)) : P in new_Qppoints_2];
    if good2 then
      return true, Q_trans, new_data1, new_data2, new_Qppoints_1, new_Qppoints_2;
    end if;
  end if;
  return false, _, _, _, _, _;
end function;



function good_patches_modp(data1, data2, p) Q := data1`Q;
  v1 := data1`v;
  v2 := data2`v;
  F := BaseRing(BaseRing(Q));
  u := F.1;
  Qp1, sigma1 := Completion(F, v1);
  Qp2, sigma2 := Completion(F, v2);
  Fp := GF(p);
  Qppoints1 := Qp_points(data1);
  Qppoints2 := Qp_points(data2);
  xs1 := [xy_coordinates(pt, data1)[1] : pt in Qppoints1 | not pt`inf];
  xs2 := [xy_coordinates(pt, data2)[1] : pt in Qppoints2 | not pt`inf];
  good_coeffs_modp := [];
  for a,b in [0..p-1] do
    if Fp!sigma1(a+b*F.1) notin xs1 and Fp!sigma2(a+b*F.1) notin xs2 then
      "trying a+b*u", a+b*u;
      A := [[1,1], [1,-(a+b*u)]];
      bool, Q_trans, new_data1, new_data2, new_Qppoints_1, new_Qppoints_2 := good_transform(Q, A, [v1,v2]);
      "bool", bool;
      if bool then
        C2 := CurveFromBivariate(Q_trans);
        //DO1 := DixmierOhnoInvariants(C1);
        //DO2 := DixmierOhnoInvariants(C2);
        //assert DixmierOhnoInvariantsEqual(DO1, DO2);
        // The above works, but only checks isomorphism over \bar{K}
        C1 := CurveFromBivariate(Q);
        assert IsIsomorphicPlaneQuartics(C1,C2);
        "works!", [a,b];
        Append(~good_coeffs_modp, [a,b]);
      end if;
    end if;
  end for;
  return good_coeffs_modp;
end function;


K<u> := CyclotomicField(3);
Q := Polynomial([PolynomialRing(CyclotomicField(3)) | [[ RationalField() | 1, 1 ], [ RationalField() | 1, -1 ], [ RationalField() | 0, 3 ], [ RationalField() | 0, -1 ]], [[ RationalField() | 0, -2 ], [ RationalField() | 0, 3 ], [ RationalField() | 0, -3 ], [ RationalField() | 2, 2 ]], [[ RationalField() | -3, 0 ]], [[ RationalField() | 2, 3 ], [ RationalField() | -1, 1 ]], [[ RationalField() | 1, 0 ]]]);
v_1 := ideal<Integers(CyclotomicField(3)) | \[ 13, 0 ], \[ 4, 1 ]>;
v_2 := ideal<Integers(CyclotomicField(3)) | \[ 13, 0 ], \[ 10, 1 ]>;
v1:=v_1;
v2:=v_2;
p := 13;
data1 := ColemanData(Q, v_1, 6);
data2 := ColemanData(Q, v_2, 6);
//good_modp := good_patches_modp(data1, data2, 13);
// One gets this A by noticing that under both embeddings there is no 
// Q13-point with x-coordinate 11 on the curve defined by Q=0, and that 
// the only bad disks are at infinity.

Patches := [];
good_modp := [
[ 0, 12 ],
[ 3, 11 ],
[ 5, 10 ],
[ 7, 4 ],
[ 8, 1 ],
[ 8, 9 ],
[ 10, 3 ],
[ 11, 0 ]
];

for pair in good_modp do
  for i,j in [0..0] do
    a := i*p+pair[1];
    b := j*p+pair[2];
    A := [[1,1], [1,-(a+b*u)]];
    Q_trans := transform(Q, A);
    bool, Q_trans, new_data1, new_data2, new_Qppoints_1, new_Qppoints_2 := good_transform(Q, A, [v1,v2] : N := 6);
    if bool then
      d:=Degree(Q_trans);

      // find the points at infinity:

      Kx := RationalFunctionField(K);
      Kxy := PolynomialRing(Kx);

      FF := function_field(Q_trans); // function field of curve over K
      infplaces:=InfinitePlaces(FF);
      infplacesKinf := infplaces;
      "a,b = ", a,b;
      "inf places", infplacesKinf;

      Kinf := K;
      for Kinf_new in infplacesKinf do
        if not IsOne(Degree(Kinf_new)) then
          // field generated by points at infinity
          //time norm_clos := NormalClosure(AbsoluteField(ResidueClassField(Kinf_new)));
          //time Kinf := Compositum(Kinf, norm_clos);
          time split := SplittingField(CharacteristicPolynomial(ResidueClassField(Kinf_new).1));
          time Kinf := Compositum(Kinf, split);
        end if;
      end for;
      dinf := AbsoluteDegree(Kinf);
      "degree of Kinf", dinf; 
      Append(~Patches, <pair, dinf>);
    end if;
  end for;
end for;


    
  
